<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Booking</div>
                    <div class="panel-body">
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/customer-booking')); ?>">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('first_name') ? ' has-error' : ''); ?>">
                                <label for="first_name" class="col-md-4 control-label">First Name</label>

                                <div class="col-md-6">
                                    <input id="first_name" type="text" class="form-control" name="first_name" value="<?php echo e(old('first_name')); ?>" required autofocus>

                                    <?php if($errors->has('first_name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('first_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('last_name') ? ' has-error' : ''); ?>">
                                <label for="last_name" class="col-md-4 control-label">Last Name</label>

                                <div class="col-md-6">
                                    <input id="last_name" type="text" class="form-control" name="last_name" value="<?php echo e(old('last_name')); ?>" required autofocus>

                                    <?php if($errors->has('last_name')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('last_name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('phone_number') ? ' has-error' : ''); ?>">
                                <label for="phone_number" class="col-md-4 control-label">Phone Number</label>

                                <div class="col-md-6">
                                    <input id="phone_number" type="text" class="form-control" name="phone_number" value="<?php echo e(old('phone_number')); ?>" required autofocus>

                                    <?php if($errors->has('phone_number')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('phone_number')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                                <label for="city" class="col-md-4 control-label">City</label>

                                <div class="col-md-6">
                                    <select id="city" name="city_id">
                                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                                <label for="date" class="col-md-4 control-label">Date</label>

                                <div class="col-md-6">
                                    <input id="date" type="text" class="form-control" name="date" value="<?php echo e(old('date')); ?>" required autofocus>

                                    <?php if($errors->has('date')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('date')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
                                <label for="time" class="col-md-4 control-label">Time</label>

                                <div class="col-md-6">
                                    <input id="time" type="text" class="form-control" name="time" value="<?php echo e(old('time')); ?>" required autofocus>

                                    <?php if($errors->has('time')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('time')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('hour') ? ' has-error' : ''); ?>">
                                <label for="hour" class="col-md-4 control-label">Hour Required</label>

                                <div class="col-md-6">
                                    <input id="hour" type="text" class="form-control" name="hour" value="<?php echo e(old('hour')); ?>" required autofocus>

                                    <?php if($errors->has('hour')): ?>
                                        <span class="help-block">
                                        <strong><?php echo e($errors->first('hour')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>



                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <button type="submit" class="btn btn-primary">
                                        Make Schedule
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
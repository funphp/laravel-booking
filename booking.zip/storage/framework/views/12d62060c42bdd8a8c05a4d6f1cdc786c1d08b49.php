<?php $__env->startSection('content'); ?>
<div class="container">

    <h1>Edit Cleaner <?php echo e($cleaner->id); ?></h1>

    <?php echo Form::model($cleaner, [
        'method' => 'PATCH',
        'url' => ['/cleaner', $cleaner->id],
        'class' => 'form-horizontal',
        'files' => true
    ]); ?>


                    <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                <?php echo Form::label('first_name', 'First Name', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('first_name', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('first_name', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                <?php echo Form::label('last_name', 'Last Name', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::text('last_name', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('last_name', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <div class="form-group <?php echo e($errors->has('quality_score') ? 'has-error' : ''); ?>">
                <?php echo Form::label('quality_score', 'Quality Score', ['class' => 'col-sm-3 control-label']); ?>

                <div class="col-sm-6">
                    <?php echo Form::number('quality_score', null, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('quality_score', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>

    <div class="form-group <?php echo e($errors->has('city') ? 'has-error' : ''); ?>">
        <?php echo Form::label('city', 'City', ['class' => 'col-sm-3 control-label']); ?>

        <div class="col-sm-6">
            <ul>
                <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><input type="checkbox" name="city[]" <?php echo e(($c['selected'] == true) ? "checked" : ''); ?>  value="<?php echo e($c->id); ?>"> <?php echo e($c->name); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    </div>


        <div class="form-group">
            <div class="col-sm-offset-3 col-sm-3">
                <?php echo Form::submit('Update', ['class' => 'btn btn-primary form-control']); ?>

            </div>
        </div>
    <?php echo Form::close(); ?>


    <?php if($errors->any()): ?>
        <ul class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>